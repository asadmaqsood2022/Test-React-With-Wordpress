import React, { useState, useEffect } from 'react';

function UserList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch(`${process.env.REACT_APP_GET_URL}/users`)
      .then(response => response.json())
      .then(users => {
        setUsers(users);
        const userPromises = users.map(user => {
          if (user.id) { 
            return fetch(`${process.env.REACT_APP_GET_URL}/usermeta/${user.id}`)
            .then(response => response.json())
            .then(usermeta => {
              user.usermeta = usermeta;
              return user;
            });
          } else {
            return Promise.resolve(user);
          }
        });
        Promise.all(userPromises).then(usersWithMeta => {
          setUsers(usersWithMeta);
        });
      });
  }, []);

  return (
    <div className="user-list">
      <h1>Users List</h1>
      <table>
        <thead>
          <tr>
            <th>User #</th>
            <th>Username</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>CNIC</th>
            <th>Date of birth</th>
            <th>Hobbies</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, index) => (
            <tr key={user.ID}>
              <td>{index+1}</td>
              <td>{user.user_login}</td> 
              <td>{user.meta.first_name}</td>
              <td>{user.meta.last_name}</td>
              <td>{user.meta.cnic}</td>
              <td>{user.meta.dob}</td>
              <td>   <div dangerouslySetInnerHTML={{ __html: user.meta.hobbies }}></div></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default UserList;
