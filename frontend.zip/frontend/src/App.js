import logo from './logo.svg';
import './App.css';
import RegistrationForm from './RegistrationForm';
import UserList from './UserList';
function App() {
  return (
    <div className="App">
     <RegistrationForm></RegistrationForm>
     <UserList></UserList>
    </div>
  );
}

export default App;
