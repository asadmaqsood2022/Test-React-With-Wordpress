import { useState } from 'react';
import { Editor } from '@tinymce/tinymce-react';
import './Form.css';

const RegistrationForm = () => {
  const [fname, setFname] = useState('');
  const [lname, setLname] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [cnic, setCnic] = useState('');
  const [dob, setDob] = useState('');
  const [hobbies, setHobbies] = useState('');

  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    
    const response = await fetch(`${process.env.REACT_APP_POST_URL}/create-user` , {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password, email, cnic, dob, hobbies, fname, lname}),
    });
    const data = await response.json();
    if (!response.ok) {
      setErrorMessage('There was an error creating your account.');
    } else {
        setSuccessMessage(`Created user with ID ${data.user_id}`);
         console.log(`Created user with ID ${data.user_id}`);
    }
  };

  return (
    <div className="user-form">

        <h1>Registration Form</h1>
        <form className="custom-form" onSubmit={handleSubmit}>
        <div className='form-warp'>
            <div className='form-row'>
            <label htmlFor="fname">First Name</label>
            <input
                type="text"
                id="username"
                value={fname}
                onChange={(event) => setFname(event.target.value)}
                maxLength={20}
                required
            />

            <label htmlFor="username">Last Name</label>
            <input
                type="text"
                id="lname"
                value={lname}
                onChange={(event) => setLname(event.target.value)}
                maxLength={20}
                required
            />
            </div>
            <div className='form-row'>
            <label htmlFor="username">Username</label>
            <input
                type="text"
                id="username"
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                maxLength={20}
                required
            />

            <label htmlFor="password">Password</label>
            <input
                type="password"
                id="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                required
            />
            </div>
            <div className='form-row'>
            <label htmlFor="email">Email</label>
            <input
                type="email"
                id="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                required
            />

            <label htmlFor=" CNIC"> CNIC</label>
        
            <input
            type="text"
            value={cnic}
            onChange={(e) => setCnic(e.target.value)}
            maxLength={15}
            required
            />
            </div>
            <div className='form-row'>
        
            <label htmlFor=" dob">  Date of Birth</label>
            <input
            type="date"
            value={dob}
            onChange={(e) => setDob(e.target.value)}
            required
            />
             </div>
            <div className='form-row'>
            <label htmlFor=" dob">  Hobbies</label>
            <Editor
            apiKey="YOUR_API_KEY"
            value={hobbies}
            onEditorChange={(content) => setHobbies(content)}
            required
            />
            </div>
        </div>

        {errorMessage && <p>{errorMessage}</p>}
        {successMessage && <p>{successMessage}</p>}
        
        <br></br>
        <button type="submit">Register</button>
        <br></br>
        <br></br>
        </form>
    </div>
  );
}

export default RegistrationForm;
